import Foundation

/// Looks up `key` in Localizable.xcstrings using the app's chosen language
/// (see AppLanguage), for use in non-View code such as view models, where
/// SwiftUI's `.environment(\.locale, ...)` on ContentView has no effect.
func L(_ key: String.LocalizationValue) -> String {
    String(localized: key, locale: AppLanguage.current.locale)
}

/// The 10 languages Cull's UI is translated into. English is the default;
/// picking another one overrides the system locale just for this app.
enum AppLanguage: String, CaseIterable, Identifiable {
    case english = "en"
    case thai = "th"
    case spanish = "es"
    case french = "fr"
    case german = "de"
    case japanese = "ja"
    case korean = "ko"
    case chineseSimplified = "zh-Hans"
    case portuguese = "pt"
    case russian = "ru"

    var id: String { rawValue }

    /// Storage key for the user's choice; read this with @AppStorage(AppLanguage.storageKey).
    static let storageKey = "appLanguage"
    static let `default` = AppLanguage.english

    var locale: Locale { Locale(identifier: rawValue) }

    /// Name written in the language itself, so people can find their own language
    /// even if the app is currently showing a language they don't read.
    var nativeName: String {
        switch self {
        case .english: "English"
        case .thai: "ไทย"
        case .spanish: "Español"
        case .french: "Français"
        case .german: "Deutsch"
        case .japanese: "日本語"
        case .korean: "한국어"
        case .chineseSimplified: "简体中文"
        case .portuguese: "Português"
        case .russian: "Русский"
        }
    }

    /// Reads the user's saved choice (the same value @AppStorage(AppLanguage.storageKey)
    /// reads and writes), for use where @AppStorage itself isn't available.
    static var current: AppLanguage {
        UserDefaults.standard.string(forKey: storageKey).flatMap(AppLanguage.init(rawValue:)) ?? .default
    }
}
