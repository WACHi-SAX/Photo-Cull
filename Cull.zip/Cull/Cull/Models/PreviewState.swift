import AppKit

struct LoadedPreview {
    let image: NSImage
    let metadata: PhotoMetadata
    let histogram: Histogram?
}

enum PreviewState: Equatable {
    case idle
    case loading
    case ready(LoadedPreview)
    case unavailable(String)

    var loaded: LoadedPreview? {
        if case let .ready(preview) = self { return preview }
        return nil
    }

    static func == (lhs: PreviewState, rhs: PreviewState) -> Bool {
        switch (lhs, rhs) {
        case (.idle, .idle), (.loading, .loading): return true
        case let (.unavailable(left), .unavailable(right)): return left == right
        case (.ready, .ready): return true
        default: return false
        }
    }
}

struct PhotoMetadata: Equatable {
    let pixelWidth: Int
    let pixelHeight: Int
    let cameraModel: String?
    let lensModel: String?
    let focalLength: Double?
    let aperture: Double?
    let exposureTime: Double?
    let iso: Int?
    let dateTaken: Date?

    var megapixels: Double { Double(pixelWidth) * Double(pixelHeight) / 1_000_000 }
}
