import CoreGraphics

/// 256-bin RGB + luminance histogram of a preview image.
struct Histogram: Equatable, Sendable {
    static let binCount = 256

    let red: [Int]
    let green: [Int]
    let blue: [Int]
    let luma: [Int]
    /// Tallest bin ignoring the pure-black and pure-white bins, so clipped spikes don't flatten the graph.
    let peak: Int

    /// Builds a histogram from a downscaled copy of `image` (fast even for 3200 px previews).
    static func make(from image: CGImage, maxDimension: Int = 512) -> Histogram? {
        let longest = max(image.width, image.height)
        guard longest > 0, let space = CGColorSpace(name: CGColorSpace.sRGB) else { return nil }
        let scale = min(1.0, Double(maxDimension) / Double(longest))
        let width = max(1, Int((Double(image.width) * scale).rounded()))
        let height = max(1, Int((Double(image.height) * scale).rounded()))
        let bytesPerRow = width * 4
        var pixels = [UInt8](repeating: 0, count: height * bytesPerRow)

        let drawn = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(
                data: buffer.baseAddress,
                width: width,
                height: height,
                bitsPerComponent: 8,
                bytesPerRow: bytesPerRow,
                space: space,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
            ) else { return false }
            context.interpolationQuality = .medium
            context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return nil }

        var red = [Int](repeating: 0, count: binCount)
        var green = red, blue = red, luma = red
        var index = 0
        while index < pixels.count {
            let alpha = Int(pixels[index + 3])
            if alpha > 0 {
                var r = Int(pixels[index]), g = Int(pixels[index + 1]), b = Int(pixels[index + 2])
                if alpha < 255 { // undo premultiplication for transparent PNGs
                    r = min(255, r * 255 / alpha)
                    g = min(255, g * 255 / alpha)
                    b = min(255, b * 255 / alpha)
                }
                red[r] += 1
                green[g] += 1
                blue[b] += 1
                luma[(54 * r + 183 * g + 19 * b) >> 8] += 1 // Rec. 709 weights, sum = 256
            }
            index += 4
        }

        let smoothedRed = smooth(red), smoothedGreen = smooth(green)
        let smoothedBlue = smooth(blue), smoothedLuma = smooth(luma)
        var peak = 1
        for bin in 1..<(binCount - 1) {
            peak = max(peak, smoothedRed[bin], smoothedGreen[bin], smoothedBlue[bin], smoothedLuma[bin])
        }
        return Histogram(red: smoothedRed, green: smoothedGreen, blue: smoothedBlue, luma: smoothedLuma, peak: peak)
    }

    /// Light [1 2 1] smoothing that leaves the end bins (clipping) untouched.
    private static func smooth(_ bins: [Int]) -> [Int] {
        var result = bins
        for i in 1..<(bins.count - 1) {
            result[i] = (bins[i - 1] + 2 * bins[i] + bins[i + 1]) / 4
        }
        return result
    }
}
