import SwiftUI

/// Overall light/dark appearance, chosen in Settings → Personalize.
enum AppTheme: String, CaseIterable, Identifiable {
    case system
    case light
    case dark

    var id: String { rawValue }
    static let storageKey = "appTheme"
    static let `default` = AppTheme.dark

    /// nil tells SwiftUI to follow the system setting.
    var colorScheme: ColorScheme? {
        switch self {
        case .system: nil
        case .light: .light
        case .dark: .dark
        }
    }

    var titleKey: LocalizedStringKey {
        switch self {
        case .system: "Match System"
        case .light: "Light"
        case .dark: "Dark"
        }
    }

    var icon: String {
        switch self {
        case .system: "circle.lefthalf.filled"
        case .light: "sun.max"
        case .dark: "moon"
        }
    }
}

/// A named accent color the person can pick in Settings → Personalize. Each case
/// supplies both a bright tint (for icons/progress bars/links on the dark backdrop)
/// and a slightly deeper fill (for solid button backgrounds), the same two-tone
/// pattern the original sea-blue theme used, so switching accents never loses the
/// contrast/readability those two tones were tuned for.
enum AccentOption: String, CaseIterable, Identifiable {
    case seaBlue
    case teal
    case violet
    case amber
    case rose

    var id: String { rawValue }
    static let storageKey = "accentOption"
    static let `default` = AccentOption.seaBlue

    /// Icons, progress bars, links, focus rings — anything shown on the dark backdrop.
    var bright: Color {
        switch self {
        case .seaBlue: Color(red: 0.36, green: 0.80, blue: 0.94)
        case .teal: Color(red: 0.31, green: 0.86, blue: 0.76)
        case .violet: Color(red: 0.70, green: 0.62, blue: 0.98)
        case .amber: Color(red: 0.98, green: 0.74, blue: 0.35)
        case .rose: Color(red: 0.98, green: 0.55, blue: 0.62)
        }
    }

    /// Solid button fills — chosen a shade deeper than `bright` so white button text
    /// keeps roughly the same contrast ratio the original sea-blue button had.
    var fill: Color {
        switch self {
        case .seaBlue: Color(red: 0.04, green: 0.47, blue: 0.66)
        case .teal: Color(red: 0.03, green: 0.49, blue: 0.42)
        case .violet: Color(red: 0.35, green: 0.24, blue: 0.62)
        case .amber: Color(red: 0.62, green: 0.42, blue: 0.06)
        case .rose: Color(red: 0.63, green: 0.16, blue: 0.28)
        }
    }

    var titleKey: LocalizedStringKey {
        switch self {
        case .seaBlue: "Sea Blue"
        case .teal: "Teal"
        case .violet: "Violet"
        case .amber: "Amber"
        case .rose: "Rose"
        }
    }
}

/// Lets any view read the chosen accent without threading it through every
/// initializer; ContentView sets this once at the root from @AppStorage.
private struct AccentOptionKey: EnvironmentKey {
    static let defaultValue: AccentOption = .default
}

extension EnvironmentValues {
    var appAccent: AccentOption {
        get { self[AccentOptionKey.self] }
        set { self[AccentOptionKey.self] = newValue }
    }
}
