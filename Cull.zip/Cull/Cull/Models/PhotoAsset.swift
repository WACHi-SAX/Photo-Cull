import Foundation

enum ImageFormat: String, Sendable {
    case jpeg = "JPEG"
    case png = "PNG"
    case heic = "HEIC"
    case raw = "RAW"

    static let rawExtensions: Set<String> = ["nef", "cr2", "cr3", "arw", "raf", "rw2", "orf", "pef", "dng"]
    static let standardExtensions: Set<String> = ["jpg", "jpeg", "png", "heic", "heif"]

    static func detect(url: URL) -> ImageFormat? {
        let ext = url.pathExtension.lowercased()
        if rawExtensions.contains(ext) { return .raw }
        switch ext {
        case "jpg", "jpeg": return .jpeg
        case "png": return .png
        case "heic", "heif": return .heic
        default: return nil
        }
    }
}

struct PhotoAsset: Identifiable, Hashable, Sendable {
    let url: URL
    let format: ImageFormat
    let byteCount: Int64?

    var id: URL { url }
    var filename: String { url.lastPathComponent }
    var isRAW: Bool { format == .raw }

    init(url: URL) {
        self.url = url
        self.format = ImageFormat.detect(url: url)!
        self.byteCount = try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize.map(Int64.init)
    }
}

enum CullingDecision: String, CaseIterable, Sendable {
    case keep = "Keep"
    case reject = "Reject"

    var folderName: String { self == .keep ? "Selected" : "Rejected" }
    var shortcut: String { self == .keep ? "1" : "2" }
}

struct DecisionEntry: Equatable, Sendable {
    let assetID: URL
    let decision: CullingDecision
}

enum TransferMode: String, CaseIterable, Identifiable {
    case copy = "Copy originals"
    case move = "Move originals"

    var id: String { rawValue }
    var completedVerb: String { L(self == .copy ? "copied" : "moved") }
    /// rawValue is also this app's storage/model identifier, so it can't itself be
    /// localized; this is the string to display instead.
    var localizedName: String { L(String.LocalizationValue(rawValue)) }
}
