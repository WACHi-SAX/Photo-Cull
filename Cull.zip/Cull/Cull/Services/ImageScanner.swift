import Foundation
import UniformTypeIdentifiers

enum ImageScannerError: LocalizedError {
    case unreadableFolder

    var errorDescription: String? { "The selected folder could not be read." }
}

struct ImageScanner {
    func discoverImages(
        in folder: URL,
        onProgress: @escaping @Sendable (Int) -> Void = { _ in }
    ) async throws -> [PhotoAsset] {
        try await Task.detached(priority: .userInitiated) {
            try discoverSynchronously(in: folder, onProgress: onProgress)
        }.value
    }

    private func discoverSynchronously(
        in folder: URL,
        onProgress: @escaping @Sendable (Int) -> Void
    ) throws -> [PhotoAsset] {
        let keys: Set<URLResourceKey> = [.isRegularFileKey, .isHiddenKey, .contentModificationDateKey, .fileSizeKey]
        guard let enumerator = FileManager.default.enumerator(
            at: folder,
            includingPropertiesForKeys: Array(keys),
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else { throw ImageScannerError.unreadableFolder }

        var assets: [PhotoAsset] = []
        for case let url as URL in enumerator {
            let values = try? url.resourceValues(forKeys: keys)
            guard values?.isRegularFile == true, ImageFormat.detect(url: url) != nil, !isVideoOrAudio(url) else { continue }
            assets.append(PhotoAsset(url: url))
            if assets.count == 1 || assets.count.isMultiple(of: 25) { onProgress(assets.count) }
        }
        onProgress(assets.count)
        return assets.sorted {
            $0.filename.localizedStandardCompare($1.filename) == .orderedAscending
        }
    }

    /// Belt-and-braces on top of the extension whitelist in ImageFormat.detect:
    /// a file's actual system-recognized type must not be a movie or other
    /// audiovisual container, even if its extension happened to be spoofed or
    /// reused (e.g. a camera clip renamed with a photo-like extension).
    private func isVideoOrAudio(_ url: URL) -> Bool {
        guard let type = UTType(filenameExtension: url.pathExtension.lowercased()) else { return false }
        return type.conforms(to: .movie) || type.conforms(to: .audiovisualContent) || type.conforms(to: .audio)
    }
}
