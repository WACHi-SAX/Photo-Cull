import Foundation

/// One saved, resumable culling session. Only the most recent unfinished session
/// is kept — this app is normally used on one input folder at a time, so a single
/// slot (rather than a list) keeps the resume flow simple.
struct SavedProgress: Codable {
    /// Security-scoped bookmark for `inputFolder`, so access survives a relaunch
    /// (a bare URL's access grant does not).
    let folderBookmark: Data
    let folderDisplayPath: String
    /// Filename -> CullingDecision.rawValue. Keyed by filename rather than full URL
    /// so a session still resumes correctly if the folder was moved or renamed.
    let decisions: [String: String]
    let totalCount: Int
    let savedAt: Date

    var decidedCount: Int { decisions.count }
}

enum ProgressStore {
    private static let key = "savedCullingProgress"

    static func load() -> SavedProgress? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(SavedProgress.self, from: data)
    }

    static func save(_ progress: SavedProgress) {
        guard let data = try? JSONEncoder().encode(progress) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    /// Explicit only — call this when the person chooses to discard a saved
    /// session, never as a side effect of finishing or leaving a session normally
    /// (see CullingSession.resetToHome, which deliberately never touches this).
    static func clear() {
        UserDefaults.standard.removeObject(forKey: key)
    }
}
