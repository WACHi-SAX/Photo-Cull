import Foundation

struct FileTransferResult {
    let transferred: Int
    let failures: [String]
}

enum FileTransferService {
    static func apply(
        decisions: [(PhotoAsset, CullingDecision)],
        destination: URL,
        mode: TransferMode,
        progress: @escaping @Sendable (Int, Int) -> Void = { _, _ in }
    ) -> FileTransferResult {
        let manager = FileManager.default
        var transferred = 0
        var failures: [String] = []
        let total = decisions.count

        for (offset, entry) in decisions.enumerated() {
            let (asset, decision) = entry
            do {
                let targetFolder = destination.appendingPathComponent(decision.folderName, isDirectory: true)
                try manager.createDirectory(at: targetFolder, withIntermediateDirectories: true)
                let target = uniqueDestination(for: asset.url, in: targetFolder, manager: manager)
                if mode == .copy {
                    try manager.copyItem(at: asset.url, to: target)
                } else {
                    try manager.moveItem(at: asset.url, to: target)
                }
                transferred += 1
            } catch {
                failures.append("\(asset.filename): \(error.localizedDescription)")
            }
            progress(offset + 1, total)
        }
        return FileTransferResult(transferred: transferred, failures: failures)
    }

    private static func uniqueDestination(for source: URL, in folder: URL, manager: FileManager) -> URL {
        let base = source.deletingPathExtension().lastPathComponent
        let ext = source.pathExtension
        var candidate = folder.appendingPathComponent(source.lastPathComponent)
        var suffix = 2
        while manager.fileExists(atPath: candidate.path) {
            candidate = folder.appendingPathComponent("\(base) \(suffix).\(ext)")
            suffix += 1
        }
        return candidate
    }
}
