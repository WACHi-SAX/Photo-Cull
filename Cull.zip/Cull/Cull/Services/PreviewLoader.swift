import AppKit
import ImageIO
import UniformTypeIdentifiers

/// NSCache needs a class; this keeps the image, its metadata and histogram together,
/// so revisiting a cached photo (e.g. after Undo) still shows the info and histogram.
private final class CachedPreview {
    let value: LoadedPreview
    init(_ value: LoadedPreview) { self.value = value }
}

final class PreviewLoader: @unchecked Sendable {
    private let cache = NSCache<NSURL, CachedPreview>()

    init() {
        cache.countLimit = 32
    }

    /// 6000 covers full-resolution output from every current consumer camera (and
    /// beyond) at 1:1 zoom on even the largest Retina displays; ImageIO never
    /// upscales past a source's native size, so this is a ceiling, not a target.
    func loadPreview(for asset: PhotoAsset, maxPixelSize: Int = 6000) async -> PreviewState {
        if let cached = cache.object(forKey: asset.url as NSURL) {
            return .ready(cached.value)
        }

        return await Task.detached(priority: .userInitiated) { [self] in
            guard let source = CGImageSourceCreateWithURL(asset.url as CFURL, nil) else {
                return .unavailable(asset.isRAW ? L("RAW preview unavailable") : L("Image could not be opened"))
            }

            // For plain JPEG/PNG/HEIC, only the small EXIF thumbnail tag counts as
            // "embedded" — asking ImageIO to prefer it (both flags false, as this used
            // to do) returns that ~160×120 thumbnail stretched to fill the view, which
            // is the blurry preview seen in testing. Forcing a fresh downsample from
            // the full image is still fast for these formats (no RAW demosaicing) and
            // gives a properly sharp preview at up to `maxPixelSize`.
            //
            // RAW files are different: their embedded preview is usually the camera's
            // own near-full-resolution JPEG, so preferring it (kept here) avoids a slow
            // full RAW decode. If a RAW has no usable embedded preview, the fallback
            // below forces one from the raw data itself.
            let options: CFDictionary = [
                kCGImageSourceCreateThumbnailFromImageAlways: !asset.isRAW,
                kCGImageSourceCreateThumbnailFromImageIfAbsent: asset.isRAW,
                kCGImageSourceThumbnailMaxPixelSize: maxPixelSize,
                kCGImageSourceShouldCacheImmediately: true,
                // Without this, ImageIO ignores the EXIF orientation tag, so portrait
                // photos (and any photo taken with the camera rotated) render sideways.
                kCGImageSourceCreateThumbnailWithTransform: true
            ] as CFDictionary

            // Fallback for a RAW whose embedded preview is missing or came back
            // smaller than requested: force a full raw decode instead.
            let fallbackOptions: CFDictionary = [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceThumbnailMaxPixelSize: max(maxPixelSize, 6000),
                kCGImageSourceShouldCacheImmediately: true,
                kCGImageSourceCreateThumbnailWithTransform: true
            ] as CFDictionary
            var preview = CGImageSourceCreateThumbnailAtIndex(source, 0, options)
            let target = min(maxPixelSize, 6000)
            if preview == nil || (asset.isRAW && max(preview!.width, preview!.height) < Int(Double(target) * 0.6)) {
                preview = CGImageSourceCreateThumbnailAtIndex(source, 0, fallbackOptions) ?? preview
            }

            guard let preview else {
                return .unavailable(asset.isRAW ? L("RAW preview unavailable") : L("Preview unavailable"))
            }

            let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any]
            let exif = properties?[kCGImagePropertyExifDictionary] as? [CFString: Any]
            let tiff = properties?[kCGImagePropertyTIFFDictionary] as? [CFString: Any]
            // kCGImagePropertyPixelWidth/Height are the raw sensor dimensions, before the
            // orientation transform above is applied. For a portrait photo (orientation
            // 5-8) that transform rotates 90°, so width and height must be swapped to
            // match what's actually shown, or the info panel reports it as landscape.
            let orientation = properties?[kCGImagePropertyOrientation] as? Int ?? 1
            let isRotated90 = (5...8).contains(orientation)
            let rawWidth = properties?[kCGImagePropertyPixelWidth] as? Int ?? preview.width
            let rawHeight = properties?[kCGImagePropertyPixelHeight] as? Int ?? preview.height
            let metadata = PhotoMetadata(
                pixelWidth: isRotated90 ? rawHeight : rawWidth,
                pixelHeight: isRotated90 ? rawWidth : rawHeight,
                cameraModel: tiff?[kCGImagePropertyTIFFModel] as? String,
                lensModel: exif?[kCGImagePropertyExifLensModel] as? String,
                focalLength: exif?[kCGImagePropertyExifFocalLength] as? Double,
                aperture: exif?[kCGImagePropertyExifFNumber] as? Double,
                exposureTime: exif?[kCGImagePropertyExifExposureTime] as? Double,
                iso: (exif?[kCGImagePropertyExifISOSpeedRatings] as? [Int])?.first,
                dateTaken: Self.captureDate(from: exif)
            )
            let image = NSImage(cgImage: preview, size: NSSize(width: preview.width, height: preview.height))
            let loaded = LoadedPreview(image: image, metadata: metadata, histogram: Histogram.make(from: preview))
            self.cache.setObject(CachedPreview(loaded), forKey: asset.url as NSURL)
            return .ready(loaded)
        }.value
    }

    func clearCache() { cache.removeAllObjects() }

    /// EXIF stores local wall-clock time without a zone ("2026:09:25 14:03:11").
    private static func captureDate(from exif: [CFString: Any]?) -> Date? {
        guard let text = exif?[kCGImagePropertyExifDateTimeOriginal] as? String else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy:MM:dd HH:mm:ss"
        return formatter.date(from: text)
    }
}
