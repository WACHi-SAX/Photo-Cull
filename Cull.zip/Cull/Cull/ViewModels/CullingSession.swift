import AppKit
import SwiftUI

enum CullingFeedback: Equatable {
    case keep
    case reject
    case undo

    /// Localized key for the on-screen badge; resolved in the View so it follows
    /// the app's chosen language reactively (see ContentView.feedbackBadge).
    var titleKey: LocalizedStringKey {
        switch self {
        case .keep: "Keep"
        case .reject: "Reject"
        case .undo: "Undo"
        }
    }
}

struct TransferOutcome: Identifiable {
    let id = UUID()
    let transferred: Int
    let failures: [String]
    let destination: URL
    let mode: TransferMode
}

@MainActor
final class CullingSession: ObservableObject {
    /// This app works with a single active session/window at a time, so the app
    /// delegate (which has no SwiftUI environment access) reaches the current
    /// session through this to ask about unsaved progress at quit time.
    static weak var shared: CullingSession?

    @Published private(set) var assets: [PhotoAsset] = []
    @Published private(set) var currentIndex = 0
    @Published private(set) var decisions: [URL: CullingDecision] = [:]
    @Published private(set) var isScanning = false
    @Published private(set) var previewState: PreviewState = .idle
    @Published private(set) var scanCount = 0
    @Published private(set) var activeFeedback: CullingFeedback?
    @Published private(set) var feedbackToken = 0
    @Published private(set) var navigationToken = 0
    @Published private(set) var isApplying = false
    @Published private(set) var applyCompleted = 0
    @Published private(set) var applyTotal = 0
    @Published private(set) var savedProgress: SavedProgress?
    @Published var inputFolder: URL?
    @Published var destinationFolder: URL?
    @Published var transferMode: TransferMode = .copy
    @Published var errorMessage: String?
    @Published var transferOutcome: TransferOutcome?

    private let scanner = ImageScanner()
    private let previewLoader = PreviewLoader()
    private var history: [DecisionEntry] = []
    private var inputFolderAccessed = false
    private var destinationFolderAccessed = false

    init() {
        Self.shared = self
        savedProgress = ProgressStore.load()
    }

    var currentAsset: PhotoAsset? { assets.indices.contains(currentIndex) ? assets[currentIndex] : nil }
    var progressText: String {
        String(format: L("count_progress_fraction"), assets.isEmpty ? 0 : min(currentIndex + 1, assets.count), assets.count)
    }
    var keepCount: Int { decisions.values.filter { $0 == .keep }.count }
    var rejectCount: Int { decisions.values.filter { $0 == .reject }.count }
    var isAtEnd: Bool { !assets.isEmpty && currentIndex >= assets.count }
    var hasDecisions: Bool { !decisions.isEmpty }
    var progressFraction: Double {
        guard !assets.isEmpty else { return 0 }
        return Double(min(currentIndex, assets.count)) / Double(assets.count)
    }
    var remainingCount: Int { max(assets.count - currentIndex, 0) }
    /// True once there's something worth offering to save: at least one decision
    /// made, and the folder hasn't been fully culled yet.
    var hasUnsavedCullingProgress: Bool { inputFolder != nil && hasDecisions && !isAtEnd }

    func chooseInputFolder() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.prompt = "Choose Folder"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        openFolder(url)
    }

    /// Shared by the folder picker above and drag-and-drop onto the welcome screen.
    func openFolder(_ url: URL) {
        startInputAccess(for: url)
        Task { await scan(folder: url) }
    }

    func chooseDestinationFolder() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.prompt = "Choose Destination"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        if destinationFolderAccessed { destinationFolder?.stopAccessingSecurityScopedResource() }
        destinationFolder = url
        destinationFolderAccessed = url.startAccessingSecurityScopedResource()
    }

    func decide(_ decision: CullingDecision) {
        guard let asset = currentAsset, !isAtEnd else { return }
        decisions[asset.id] = decision
        history.append(DecisionEntry(assetID: asset.id, decision: decision))
        currentIndex += 1
        navigationToken += 1
        showFeedback(decision == .keep ? .keep : .reject)
        loadCurrentPreview()
    }

    func undo() {
        guard let last = history.popLast(), let index = assets.firstIndex(where: { $0.id == last.assetID }) else { return }
        decisions.removeValue(forKey: last.assetID)
        currentIndex = index
        navigationToken += 1
        showFeedback(.undo)
        loadCurrentPreview()
    }

    func decision(for asset: PhotoAsset) -> CullingDecision? { decisions[asset.id] }

    func applyChanges() {
        guard let destinationFolder else {
            errorMessage = L("error_choose_destination")
            return
        }
        let work = assets.compactMap { asset -> (PhotoAsset, CullingDecision)? in
            guard let decision = decisions[asset.id] else { return nil }
            return (asset, decision)
        }
        guard !work.isEmpty else { return }
        let mode = transferMode
        isApplying = true
        applyCompleted = 0
        applyTotal = work.count
        let reportProgress: @Sendable (Int, Int) -> Void = { [weak self] completed, total in
            Task { @MainActor [weak self] in
                self?.applyCompleted = completed
                self?.applyTotal = total
            }
        }

        Task {
            let result = await Task.detached(priority: .userInitiated) {
                FileTransferService.apply(
                    decisions: work,
                    destination: destinationFolder,
                    mode: mode,
                    progress: reportProgress
                )
            }.value
            isApplying = false
            transferOutcome = TransferOutcome(
                transferred: result.transferred,
                failures: result.failures,
                destination: destinationFolder,
                mode: mode
            )
        }
    }

    /// Resets all session state back to the initial "choose a folder" screen, the
    /// same state as a fresh app launch. Deliberately never touches ProgressStore
    /// itself — saving is always a separate, explicit step (see saveProgress()),
    /// so this never risks discarding a session the person hasn't chosen to give up.
    func resetToHome() {
        if inputFolderAccessed { inputFolder?.stopAccessingSecurityScopedResource() }
        if destinationFolderAccessed { destinationFolder?.stopAccessingSecurityScopedResource() }
        inputFolder = nil
        destinationFolder = nil
        inputFolderAccessed = false
        destinationFolderAccessed = false
        assets = []
        decisions = [:]
        history = []
        currentIndex = 0
        scanCount = 0
        previewState = .idle
        activeFeedback = nil
        transferOutcome = nil
        previewLoader.clearCache()
        savedProgress = ProgressStore.load()
    }

    /// Shows the native Save/Discard/Cancel alert for leaving mid-culling. Used by
    /// both the window's own close button and Cmd+Q / the Quit menu, so the same
    /// prompt and logic apply no matter which way the person tries to leave.
    /// Returns true if it's fine to proceed (already saved or explicitly
    /// discarded, or nothing to save), false if the person cancelled.
    @discardableResult
    func confirmDiscardOrSaveBeforeClosing() -> Bool {
        guard hasUnsavedCullingProgress else { return true }
        let alert = NSAlert()
        alert.messageText = L("quit_save_title")
        alert.informativeText = String(format: L("quit_save_message"), keepCount + rejectCount, assets.count)
        alert.addButton(withTitle: L("action_save_and_quit"))
        alert.addButton(withTitle: L("action_discard_and_quit"))
        alert.addButton(withTitle: L("Cancel"))
        switch alert.runModal() {
        case .alertFirstButtonReturn: saveProgress(); return true
        case .alertSecondButtonReturn: return true
        default: return false
        }
    }

    /// Writes the current folder + decisions to disk so `resumeSavedProgress()`
    /// can pick it back up next launch. Call this before `resetToHome()` — that
    /// call clears the very state this needs.
    func saveProgress() {
        guard let inputFolder, hasDecisions else { return }
        guard let bookmark = try? inputFolder.bookmarkData(
            options: [.withSecurityScope], includingResourceValuesForKeys: nil, relativeTo: nil
        ) else { return }
        let raw = Dictionary(decisions.map { ($0.key.lastPathComponent, $0.value.rawValue) }, uniquingKeysWith: { _, latest in latest })
        ProgressStore.save(SavedProgress(
            folderBookmark: bookmark,
            folderDisplayPath: inputFolder.path,
            decisions: raw,
            totalCount: assets.count,
            savedAt: Date()
        ))
    }

    /// Explicit only — the person tapping "Start Fresh" on the resume card. Never
    /// called as a side effect of finishing or leaving a session normally.
    func discardSavedProgress() {
        ProgressStore.clear()
        savedProgress = nil
    }

    /// Resolves the saved folder, re-scans it, then restores each photo's saved
    /// decision by filename and jumps to the first photo that's still undecided.
    func resumeSavedProgress() {
        guard let saved = savedProgress else { return }
        var isStale = false
        guard let url = try? URL(
            resolvingBookmarkData: saved.folderBookmark, options: [.withSecurityScope],
            relativeTo: nil, bookmarkDataIsStale: &isStale
        ) else {
            errorMessage = L("error_resume_failed")
            discardSavedProgress()
            return
        }
        startInputAccess(for: url)
        let savedDecisions = saved.decisions
        savedProgress = nil
        Task {
            await scan(folder: url)
            restoreDecisions(savedDecisions)
        }
    }

    private func restoreDecisions(_ raw: [String: String]) {
        var restored: [URL: CullingDecision] = [:]
        for asset in assets {
            if let value = raw[asset.filename], let decision = CullingDecision(rawValue: value) {
                restored[asset.id] = decision
            }
        }
        decisions = restored
        currentIndex = assets.firstIndex { restored[$0.id] == nil } ?? assets.count
        navigationToken += 1
        loadCurrentPreview()
    }

    private func startInputAccess(for url: URL) {
        if inputFolderAccessed { inputFolder?.stopAccessingSecurityScopedResource() }
        inputFolder = url
        inputFolderAccessed = url.startAccessingSecurityScopedResource()
    }

    private func scan(folder: URL) async {
        isScanning = true
        assets = []
        decisions = [:]
        history = []
        currentIndex = 0
        scanCount = 0
        previewState = .idle
        previewLoader.clearCache()
        do {
            assets = try await scanner.discoverImages(in: folder) { [weak self] count in
                Task { @MainActor [weak self] in self?.scanCount = count }
            }
            if assets.isEmpty { errorMessage = L("error_no_photos_found") }
            loadCurrentPreview()
        } catch {
            errorMessage = error.localizedDescription
        }
        isScanning = false
    }

    private func loadCurrentPreview() {
        guard let asset = currentAsset, !isAtEnd else {
            previewState = .idle
            return
        }
        previewState = .loading
        Task {
            let result = await previewLoader.loadPreview(for: asset)
            guard currentAsset?.id == asset.id else { return }
            previewState = result
        }
    }

    private func showFeedback(_ feedback: CullingFeedback) {
        feedbackToken += 1
        let token = feedbackToken
        activeFeedback = feedback
        Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(230))
            guard self?.feedbackToken == token else { return }
            self?.activeFeedback = nil
        }
    }
}
