import AppKit
import SwiftUI

struct PhotoViewer: View {
    let state: PreviewState
    let assetID: URL?
    let zoomCommand: Int
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.black.opacity(0.78))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(CullDesign.hairline, lineWidth: 1))
            switch state {
            case .idle:
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 46, weight: .ultraLight))
                    .foregroundStyle(CullDesign.muted)
            case .loading:
                ProgressView().controlSize(.large).tint(.white.opacity(0.8))
                    .transition(.opacity)
            case let .ready(preview):
                ZoomableImage(image: preview.image, assetID: assetID, zoomCommand: zoomCommand)
                    .padding(12)
                    .transition(reduceMotion ? .opacity : .opacity.combined(with: .scale(scale: 0.985)))
            case let .unavailable(message):
                VStack(spacing: 12) {
                    Image(systemName: "camera.aperture")
                        .font(.system(size: 42, weight: .ultraLight))
                    Text(message).font(.headline)
                    Text(assetID?.pathExtension.uppercased() ?? "RAW")
                        .font(.caption.weight(.semibold)).foregroundStyle(CullDesign.muted)
                    Text("The original file is still ready to cull.")
                        .font(.caption).foregroundStyle(CullDesign.muted)
                }
                .accessibilityElement(children: .combine)
                .transition(.opacity)
            }
        }
        .animation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.86), value: assetID)
    }
}

private struct ZoomableImage: View {
    let image: NSImage
    let assetID: URL?
    let zoomCommand: Int
    @State private var scale: CGFloat = 1
    @State private var previousScale: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var previousOffset: CGSize = .zero
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private let minScale: CGFloat = 1
    private let maxScale: CGFloat = 5
    private let doubleTapScale: CGFloat = 2.5

    var body: some View {
        GeometryReader { proxy in
            let containerSize = proxy.size
            Image(nsImage: image)
                .resizable()
                .interpolation(.high)
                .aspectRatio(contentMode: .fit)
                .scaleEffect(scale)
                .offset(offset)
                .frame(width: containerSize.width, height: containerSize.height)
                .clipped()
                .contentShape(Rectangle())
                .gesture(dragGesture(in: containerSize))
                .simultaneousGesture(magnifyGesture(in: containerSize))
                .gesture(SpatialTapGesture(count: 2).onEnded { tap in
                    toggleZoom(at: tap.location, in: containerSize)
                })
                .onChange(of: assetID) { _, _ in resetZoom(animated: false) }
                .onChange(of: zoomCommand) { _, _ in
                    toggleZoom(at: CGPoint(x: containerSize.width / 2, y: containerSize.height / 2), in: containerSize, targetScale: 2)
                }
                .onHover { hovering in
                    if scale > 1.01 { hovering ? NSCursor.openHand.set() : NSCursor.arrow.set() }
                }
                .overlay(alignment: .bottomTrailing) {
                    if scale > 1.01 {
                        zoomBadge
                    }
                }
                .accessibilityLabel("Photo preview")
                .accessibilityHint("Double click or press Space to toggle 100 percent zoom")
        }
    }

    private var zoomBadge: some View {
        Text(String(format: "%.0f%%", scale * 100))
            .font(.caption2.weight(.semibold).monospacedDigit())
            .foregroundStyle(.white.opacity(0.9))
            .padding(.horizontal, 8).padding(.vertical, 4)
            .background(.black.opacity(0.55), in: Capsule())
            .padding(10)
            .transition(.scale(scale: 0.7).combined(with: .opacity))
    }

    private func dragGesture(in containerSize: CGSize) -> some Gesture {
        DragGesture(minimumDistance: 2)
            .onChanged { value in
                guard scale > 1.01 else { return }
                let proposed = CGSize(
                    width: previousOffset.width + value.translation.width,
                    height: previousOffset.height + value.translation.height
                )
                offset = clampedOffset(proposed, scale: scale, in: containerSize)
            }
            .onEnded { _ in previousOffset = offset }
    }

    private func magnifyGesture(in containerSize: CGSize) -> some Gesture {
        MagnificationGesture()
            .onChanged { value in
                scale = min(max(previousScale * value, minScale), maxScale)
                offset = clampedOffset(offset, scale: scale, in: containerSize)
            }
            .onEnded { _ in
                withAnimation(reduceMotion ? nil : .easeOut(duration: 0.15)) {
                    if scale < 1.04 { scale = 1; offset = .zero }
                }
                previousScale = scale
                previousOffset = offset
            }
    }

    /// Zooms toward `location` (the tap/click point in the container's local
    /// coordinates) instead of always re-centering, so the spot the person is
    /// actually looking at stays under their cursor.
    private func toggleZoom(at location: CGPoint, in containerSize: CGSize, targetScale: CGFloat? = nil) {
        if scale > 1.01 {
            resetZoom(animated: true)
            return
        }
        let target = min(targetScale ?? doubleTapScale, maxScale)
        let center = CGPoint(x: containerSize.width / 2, y: containerSize.height / 2)
        let proposed = CGSize(width: (center.x - location.x) * (target - 1), height: (center.y - location.y) * (target - 1))
        let animation: Animation? = reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.78)
        withAnimation(animation) {
            scale = target
            offset = clampedOffset(proposed, scale: target, in: containerSize)
        }
        previousScale = target
        previousOffset = offset
    }

    private func resetZoom(animated: Bool) {
        let change = { scale = 1; previousScale = 1; offset = .zero; previousOffset = .zero }
        if animated, !reduceMotion { withAnimation(.spring(response: 0.32, dampingFraction: 0.8), change) } else { change() }
    }

    /// Keeps panning within the image's actual edges at the current zoom level
    /// (rather than letting it drag away to blank space indefinitely).
    private func clampedOffset(_ proposed: CGSize, scale: CGFloat, in containerSize: CGSize) -> CGSize {
        guard image.size.width > 0, image.size.height > 0, containerSize.width > 0, containerSize.height > 0 else { return .zero }
        let fitScale = min(containerSize.width / image.size.width, containerSize.height / image.size.height)
        let fittedSize = CGSize(width: image.size.width * fitScale, height: image.size.height * fitScale)
        let scaledSize = CGSize(width: fittedSize.width * scale, height: fittedSize.height * scale)
        let maxX = max(0, (scaledSize.width - containerSize.width) / 2)
        let maxY = max(0, (scaledSize.height - containerSize.height) / 2)
        return CGSize(
            width: min(max(proposed.width, -maxX), maxX),
            height: min(max(proposed.height, -maxY), maxY)
        )
    }
}
