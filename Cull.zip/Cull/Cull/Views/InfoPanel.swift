import SwiftUI

/// Photo information card shown beside the preview (top-right of the window).
struct InfoPanel: View {
    let asset: PhotoAsset
    let preview: LoadedPreview?
    @Environment(\.appAccent) private var accent

    private var metadata: PhotoMetadata? { preview?.metadata }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            Divider().overlay(CullDesign.hairline)
            section("Camera") {
                row("Body", metadata?.cameraModel)
                row("Lens", metadata?.lensModel)
            }
            section("Exposure") {
                row("Focal length", metadata?.focalLength.map { "\(Int($0.rounded())) mm" })
                row("Aperture", metadata?.aperture.map { String(format: "f/%.1f", $0) })
                row("Shutter", metadata?.exposureTime.map(shutterText))
                row("ISO", metadata?.iso.map { String($0) })
            }
            section("Image") {
                row("Dimensions", metadata.map { "\($0.pixelWidth) × \($0.pixelHeight)" })
                row("Resolution", metadata.map { String(format: "%.1f MP", $0.megapixels) })
                row("Captured", metadata?.dateTaken?.formatted(date: .abbreviated, time: .shortened))
            }
        }
        .padding(12)
        .glassBar()
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(asset.filename)
                .font(.callout.weight(.semibold))
                .lineLimit(2)
                .truncationMode(.middle)
            HStack(spacing: 8) {
                Text(asset.format.rawValue)
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(accent.bright)
                    .padding(.horizontal, 6).padding(.vertical, 2)
                    .background(accent.bright.opacity(0.10), in: Capsule())
                if let bytes = asset.byteCount {
                    Text(ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file))
                        .font(.caption).foregroundStyle(CullDesign.muted)
                }
            }
        }
        .accessibilityElement(children: .combine)
    }

    private func section<Content: View>(_ title: LocalizedStringKey, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption2.weight(.semibold)).tracking(0.6).textCase(.uppercase)
                .foregroundStyle(accent.bright)
            content()
        }
    }

    private func row(_ label: LocalizedStringKey, _ value: String?) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(label).foregroundStyle(CullDesign.muted)
            Spacer(minLength: 8)
            Text(value ?? "—")
                .foregroundStyle(value == nil ? CullDesign.muted : .primary)
                .multilineTextAlignment(.trailing)
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)
        }
        .font(.caption)
        .accessibilityElement(children: .combine)
    }

    private func shutterText(_ shutter: Double) -> String {
        shutter < 1 ? "1/\(Int((1 / shutter).rounded())) s" : String(format: "%.1f s", shutter)
    }
}
