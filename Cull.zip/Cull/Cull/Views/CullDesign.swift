import SwiftUI

/// Design tokens for Cull. Main brand colour: sea blue (ฟ้าน้ำทะเล) — now the
/// *default* accent; the actual accent in use can be changed in Settings →
/// Personalize and is read live via `@Environment(\.appAccent)` everywhere below.
enum CullDesign {
    // MARK: Sea-blue theme (default accent, also the fallback if no accent is set)
    /// Fill colour for prominent buttons. White labels on it reach ~4.9:1 contrast.
    static let seaBlue = AccentOption.seaBlue.fill
    /// Lighter sea blue for text, icons, progress bars and tints on dark backgrounds (~9.8:1).
    static let seaBlueBright = AccentOption.seaBlue.bright
    static let deepSea = Color(red: 0.02, green: 0.13, blue: 0.20)
    static let abyss = Color(red: 0.01, green: 0.04, blue: 0.07)

    // MARK: Surfaces
    static let panel = seaBlueBright.opacity(0.10)
    static let hairline = seaBlueBright.opacity(0.18)
    static let muted = Color.white.opacity(0.58)

    // MARK: Semantic colours (state, not theme — never follow the accent picker)
    static let green = Color(red: 0.40, green: 0.88, blue: 0.60)
    static let red = Color(red: 1.0, green: 0.42, blue: 0.42)
    /// Darker green used only as a button fill so white labels stay readable (~5:1).
    static let keepFill = Color(red: 0.08, green: 0.50, blue: 0.32)

    static let cornerRadius: CGFloat = 12
    /// Space reserved for the traffic-light buttons because the title bar is hidden.
    static let windowControlsInset: CGFloat = 78
    /// Width of the info (right) and histogram (left) side panels.
    static let sidePanelWidth: CGFloat = 240
    /// Standard tappable size for icon-only buttons — sized up from the original
    /// 24pt so every control is comfortably clickable.
    static let iconButtonSize: CGFloat = 30
}

/// Deep-sea window background with soft light glows tinted to the chosen accent.
struct SeaBackdrop: View {
    @Environment(\.appAccent) private var accent

    var body: some View {
        ZStack {
            LinearGradient(colors: [CullDesign.deepSea, CullDesign.abyss], startPoint: .top, endPoint: .bottom)
            RadialGradient(colors: [accent.fill.opacity(0.30), .clear],
                           center: .topLeading, startRadius: 0, endRadius: 620)
            RadialGradient(colors: [accent.bright.opacity(0.10), .clear],
                           center: .bottomTrailing, startRadius: 0, endRadius: 520)
        }
    }
}

struct ShortcutHint: View {
    let key: String
    let title: LocalizedStringKey
    @Environment(\.appAccent) private var accent

    var body: some View {
        HStack(spacing: 5) {
            Text(key)
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .foregroundStyle(accent.bright)
                .padding(.horizontal, 6).padding(.vertical, 3)
                .background(accent.bright.opacity(0.12), in: RoundedRectangle(cornerRadius: 4, style: .continuous))
            Text(title).font(.caption).foregroundStyle(CullDesign.muted)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(Text("\(key), ") + Text(title))
    }
}

struct GlassBar: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial.opacity(0.72), in: RoundedRectangle(cornerRadius: CullDesign.cornerRadius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: CullDesign.cornerRadius, style: .continuous).stroke(CullDesign.hairline, lineWidth: 1))
    }
}

/// Filled, tinted button with a springy press-down bounce, replacing the flatter
/// system `.borderedProminent` look used before. Sized up from the original
/// bordered-prominent defaults so buttons are easier to hit.
struct PrimaryButtonStyle: ButtonStyle {
    /// nil means "follow the person's chosen accent color" — pass an explicit
    /// color only for semantic actions (Keep = green, Reject = red) that must
    /// never change with the theme.
    var tint: Color?
    @Environment(\.controlSize) private var controlSize
    @Environment(\.isEnabled) private var isEnabled
    @Environment(\.appAccent) private var accent

    func makeBody(configuration: Configuration) -> some View {
        let resolved = tint ?? accent.fill
        configuration.label
            .font(controlSize == .large ? .title3.weight(.semibold) : .headline)
            .foregroundStyle(.white)
            .padding(.horizontal, controlSize == .large ? 26 : 18)
            .padding(.vertical, controlSize == .large ? 14 : 10)
            .background(
                RoundedRectangle(cornerRadius: CullDesign.cornerRadius, style: .continuous)
                    .fill(isEnabled ? resolved : resolved.opacity(0.35))
            )
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.55), value: configuration.isPressed)
    }
}

/// Subtle press/spring feedback for plain icon-only buttons (folder, undo, zoom…),
/// tinted to the person's chosen accent so every icon button in the app matches.
struct IconButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled
    @Environment(\.appAccent) private var accent

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(accent.bright)
            .frame(width: CullDesign.iconButtonSize, height: CullDesign.iconButtonSize)
            .contentShape(Rectangle())
            .opacity(isEnabled ? (configuration.isPressed ? 0.55 : 1) : 0.35)
            .scaleEffect(configuration.isPressed ? 0.86 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

/// A small text bubble that pops up above a control on hover, with a spring
/// scale-in — used alongside (or instead of) the system `.help()` tooltip, which
/// has a long fixed delay and no animation of its own.
struct HoverTooltip: ViewModifier {
    let text: LocalizedStringKey
    @State private var isHovering = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func body(content: Content) -> some View {
        content
            .overlay(alignment: .top) {
                if isHovering {
                    Text(text)
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 9).padding(.vertical, 5)
                        .background(.black.opacity(0.85), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
                        .fixedSize()
                        .offset(y: -34)
                        .transition(reduceMotion ? .opacity :
                            .scale(scale: 0.7, anchor: .bottom).combined(with: .opacity))
                        .zIndex(10)
                        .allowsHitTesting(false)
                }
            }
            .onHover { hovering in
                withAnimation(reduceMotion ? nil : .spring(response: 0.28, dampingFraction: 0.62)) {
                    isHovering = hovering
                }
            }
    }
}

extension View {
    func glassBar() -> some View { modifier(GlassBar()) }

    /// Prominent button following the person's chosen accent color, unless a
    /// specific `tint` is given for a semantic action (Keep/Reject).
    func primaryAction(tint: Color? = nil) -> some View {
        buttonStyle(PrimaryButtonStyle(tint: tint))
    }

    /// Plain icon button (folder, undo, zoom, info…) with a light press bounce,
    /// tinted to the chosen accent, at a consistent easy-to-hit size.
    func iconButton() -> some View {
        buttonStyle(IconButtonStyle())
    }

    /// Animated popup label shown on hover, in addition to the system tooltip.
    func hoverTooltip(_ text: LocalizedStringKey) -> some View {
        modifier(HoverTooltip(text: text))
    }
}
