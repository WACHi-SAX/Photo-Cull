import AppKit
import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var session = CullingSession()
    @State private var showReview = false
    @State private var showInfo = true
    @State private var zoomCommand = 0
    @State private var controlsVisible = true
    @State private var isFullScreen = false
    @State private var inactivityTask: Task<Void, Never>?
    @State private var showTutorial = false
    @State private var showHomeConfirm = false
    @State private var isDropTargeted = false
    @AppStorage(AppLanguage.storageKey) private var appLanguageRaw = AppLanguage.default.rawValue
    @AppStorage("hasSeenTutorial") private var hasSeenTutorial = false
    @AppStorage(AppTheme.storageKey) private var themeRaw = AppTheme.default.rawValue
    @AppStorage(AccentOption.storageKey) private var accentRaw = AccentOption.default.rawValue
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.openSettings) private var openSettings

    private var appLanguage: AppLanguage { AppLanguage(rawValue: appLanguageRaw) ?? .default }
    private var theme: AppTheme { AppTheme(rawValue: themeRaw) ?? .default }
    private var accent: AccentOption { AccentOption(rawValue: accentRaw) ?? .default }

    var body: some View {
        ZStack {
            if session.inputFolder == nil {
                welcomeView
            } else if session.isScanning {
                scanningView
            } else if session.assets.isEmpty {
                emptyResultsView
            } else {
                cullingView
            }
            if session.isApplying { applyingOverlay }
            if showTutorial {
                TutorialView(onFinish: {
                    hasSeenTutorial = true
                    showTutorial = false
                })
                .zIndex(30)
                .transition(.opacity)
            }
        }
        // .id forces every Text(LocalizedStringKey) to re-resolve immediately when the
        // language changes, rather than only on the next unrelated state update.
        .id(appLanguageRaw)
        .environment(\.locale, appLanguage.locale)
        .environment(\.appAccent, accent)
        .preferredColorScheme(theme.colorScheme)
        .tint(accent.bright)
        .background { SeaBackdrop().ignoresSafeArea() }
        .sheet(isPresented: $showReview) {
            ReviewSheet(session: session, onApply: session.applyChanges)
        }
        .sheet(item: $session.transferOutcome) { outcome in
            CompletionSheet(
                outcome: outcome,
                onDismiss: { session.transferOutcome = nil },
                onStartOver: {
                    // Small delay so the sheet dismiss animation finishes first.
                    Task {
                        try? await Task.sleep(for: .milliseconds(200))
                        withAnimation(.spring(response: 0.45, dampingFraction: 0.82)) {
                            session.resetToHome()
                        }
                    }
                }
            )
        }
        .alert("Photo Cull", isPresented: Binding(
            get: { session.errorMessage != nil },
            set: { if !$0 { session.errorMessage = nil } }
        )) { Button("OK", role: .cancel) {} } message: { Text(session.errorMessage ?? "") }
        .confirmationDialog(
            "Save your progress?",
            isPresented: $showHomeConfirm,
            titleVisibility: .visible
        ) {
            Button("Save & Go Home") {
                session.saveProgress()
                withAnimation(reduceMotion ? nil : .spring(response: 0.4, dampingFraction: 0.82)) {
                    session.resetToHome()
                }
            }
            Button("Discard & Go Home", role: .destructive) {
                withAnimation(reduceMotion ? nil : .spring(response: 0.4, dampingFraction: 0.82)) {
                    session.resetToHome()
                }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text(String(format: L("confirm_save_message"), session.keepCount + session.rejectCount, session.assets.count))
        }
        .background(KeyEventMonitor(onKeyDown: handleKeyDown, onMouseActivity: recordMouseActivity).frame(width: 0, height: 0))
        .background(WindowCloseGuard(shouldClose: session.confirmDiscardOrSaveBeforeClosing).frame(width: 0, height: 0))
        .onAppear {
            recordMouseActivity()
            if !hasSeenTutorial { showTutorial = true }
        }
        .onReceive(NotificationCenter.default.publisher(for: .replayTutorial)) { _ in
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) { showTutorial = true }
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWindow.didEnterFullScreenNotification)) { _ in isFullScreen = true }
        .onReceive(NotificationCenter.default.publisher(for: NSWindow.didExitFullScreenNotification)) { _ in isFullScreen = false }
    }

    /// Globe menu for switching the app's display language; English is the default
    /// regardless of the system language, until the person picks another one here.
    private var languageMenu: some View {
        Menu {
            ForEach(AppLanguage.allCases) { language in
                Button {
                    appLanguageRaw = language.rawValue
                } label: {
                    if language == appLanguage {
                        Label(language.nativeName, systemImage: "checkmark")
                    } else {
                        Text(language.nativeName)
                    }
                }
            }
        } label: {
            Image(systemName: "globe")
                .frame(width: CullDesign.iconButtonSize, height: CullDesign.iconButtonSize)
                .contentShape(Rectangle())
        }
        .menuStyle(.borderlessButton)
        .fixedSize()
        .buttonStyle(.plain)
        .foregroundStyle(accent.bright)
        .help("Language")
        .accessibilityLabel("Language")
        .hoverTooltip("Language")
    }

    private var welcomeView: some View {
        ZStack(alignment: .topTrailing) {
            VStack(spacing: 28) {
                Spacer(minLength: 20)
                VStack(spacing: 18) {
                    Image("AppLogo")
                        .resizable()
                        .interpolation(.high)
                        .scaledToFit()
                        .frame(width: 118, height: 118)
                        .shadow(color: accent.bright.opacity(0.35), radius: 22)
                        .accessibilityHidden(true)
                    VStack(spacing: 7) {
                        Text("Photo Cull").font(.system(size: 34, weight: .semibold, design: .rounded))
                        Text("Fast photo selection for photographers.")
                            .foregroundStyle(CullDesign.muted)
                    }
                }
                featureHighlights
                dropZone
                if let saved = session.savedProgress {
                    resumeCard(saved)
                }
                Spacer(minLength: 8)
                HStack(spacing: 14) {
                    languageMenu
                    Button { openSettings() } label: { Image(systemName: "gearshape") }
                        .iconButton()
                        .help("Settings").accessibilityLabel("Settings")
                        .hoverTooltip("Settings")
                    Text(String(format: L("about_version"), "1.0"))
                        .font(.caption2).foregroundStyle(CullDesign.muted.opacity(0.7))
                }
                .padding(.bottom, 18)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .animation(reduceMotion ? nil : .spring(response: 0.4, dampingFraction: 0.8), value: session.savedProgress != nil)
        .animation(reduceMotion ? nil : .spring(response: 0.3, dampingFraction: 0.7), value: isDropTargeted)
        .onDrop(of: [.fileURL], isTargeted: $isDropTargeted, perform: handleFolderDrop)
    }

    /// Three quick highlights so the welcome screen explains itself instead of
    /// sitting empty above the one button.
    private var featureHighlights: some View {
        HStack(spacing: 14) {
            featurePill(icon: "keyboard", title: "Keyboard-first")
            featurePill(icon: "camera.aperture", title: "RAW support")
            featurePill(icon: "tray.and.arrow.down", title: "Auto-sorts files")
        }
    }

    private func featurePill(icon: String, title: LocalizedStringKey) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon).font(.title3).foregroundStyle(accent.bright)
            Text(title).font(.caption).foregroundStyle(CullDesign.muted).multilineTextAlignment(.center)
        }
        .frame(width: 108, height: 76)
        .glassBar()
    }

    /// Doubles as the "Choose Photo Folder" call to action and a drop target for
    /// dragging a folder in from Finder.
    private var dropZone: some View {
        Button(action: session.chooseInputFolder) {
            VStack(spacing: 10) {
                Image(systemName: isDropTargeted ? "folder.fill.badge.plus" : "folder")
                    .font(.system(size: 30, weight: .light))
                Text("Choose Photo Folder").font(.headline)
                Text("or drag a folder here").font(.caption).foregroundStyle(CullDesign.muted)
            }
            .foregroundStyle(isDropTargeted ? accent.bright : .primary)
            .frame(width: 320, height: 130)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(isDropTargeted ? accent.bright.opacity(0.14) : Color.white.opacity(0.04))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(isDropTargeted ? accent.bright : CullDesign.hairline,
                                  style: StrokeStyle(lineWidth: isDropTargeted ? 2 : 1.5, dash: [7, 6]))
            )
            .scaleEffect(isDropTargeted ? 1.03 : 1)
        }
        .buttonStyle(.plain)
        .accessibilityHint("Opens a folder picker, or drop a folder here")
    }

    private func handleFolderDrop(_ providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first(where: { $0.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) }) else { return false }
        provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier) { data, _ in
            guard let data = data as? Data, let url = URL(dataRepresentation: data, relativeTo: nil) else { return }
            var isDirectory: ObjCBool = false
            guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory), isDirectory.boolValue else { return }
            DispatchQueue.main.async { session.openFolder(url) }
        }
        return true
    }

    /// Offered on the welcome screen whenever an earlier, unfinished session was
    /// saved (see CullingSession.saveProgress / resumeSavedProgress).
    private func resumeCard(_ saved: SavedProgress) -> some View {
        VStack(spacing: 10) {
            HStack(spacing: 7) {
                Image(systemName: "clock.arrow.circlepath").foregroundStyle(accent.bright)
                Text("Continue where you left off").font(.subheadline.weight(.semibold))
            }
            Text(saved.folderDisplayPath)
                .font(.caption).foregroundStyle(CullDesign.muted)
                .lineLimit(1).truncationMode(.head)
            Text(String(format: L("resume_progress_fraction"), saved.decidedCount, saved.totalCount))
                .font(.caption2).foregroundStyle(CullDesign.muted)
            HStack(spacing: 14) {
                Button("Start Fresh") {
                    withAnimation(reduceMotion ? nil : .easeOut(duration: 0.18)) { session.discardSavedProgress() }
                }
                .buttonStyle(.plain)
                .foregroundStyle(CullDesign.muted)
                Button("Continue", action: session.resumeSavedProgress)
                    .primaryAction()
            }
        }
        .padding(16)
        .frame(width: 320)
        .glassBar()
        .transition(reduceMotion ? .opacity : .scale(scale: 0.94).combined(with: .opacity))
    }


    private var scanningView: some View {
        VStack(spacing: 16) {
            ProgressView().controlSize(.large)
            VStack(spacing: 5) {
                Text("Scanning photos…").font(.title3.weight(.medium))
                Text(session.scanCount == 0 ? "Looking for supported images" : "\(session.scanCount) images found")
                    .foregroundStyle(CullDesign.muted)
                    .contentTransition(.numericText())
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var emptyResultsView: some View {
        VStack(spacing: 14) {
            Image(systemName: "rectangle.stack.badge.exclamationmark").font(.system(size: 38, weight: .ultraLight)).foregroundStyle(CullDesign.muted)
            Text("No supported photos found").font(.title2.weight(.medium))
            Text("Cull recognizes JPEG, PNG, HEIC/HEIF, and NEF, CR2, CR3, ARW, RAF, RW2, ORF, PEF, and DNG RAW files.")
                .multilineTextAlignment(.center).foregroundStyle(.secondary).frame(maxWidth: 550)
            HStack(spacing: 14) {
                Button("Back to Home") { session.resetToHome() }
                    .buttonStyle(.plain).foregroundStyle(CullDesign.muted)
                Button("Choose Another Folder", action: session.chooseInputFolder)
                    .primaryAction()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var cullingView: some View {
        ZStack(alignment: .bottomTrailing) {
            VStack(spacing: 0) {
                topBar
                    .opacity(controlsVisible ? 1 : 0.32)
                if session.isAtEnd { completedView } else { viewerContent }
                controls
                    .opacity(controlsVisible ? 1 : 0.25)
            }
            // Pulled out of the control row and anchored to the corner (was a plain
            // row under the buttons before), with its own card so it reads clearly
            // as a reference rather than blending into the rest of the toolbar.
            shortcutHintsBar
                .opacity(controlsVisible ? 1 : 0)
                .padding(.trailing, 22)
                .padding(.bottom, 92)
            if let feedback = session.activeFeedback {
                feedbackBadge(feedback)
                    .transition(reduceMotion ? .opacity : .scale(scale: 0.7).combined(with: .opacity))
                    .zIndex(2)
            }
        }
        .animation(reduceMotion ? nil : .easeOut(duration: 0.15), value: controlsVisible)
        .animation(reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.62), value: session.activeFeedback)
    }

    private var topBar: some View {
        VStack(spacing: 8) {
            HStack(spacing: 10) {
                Image("AppLogo")
                    .resizable()
                    .interpolation(.high)
                    .scaledToFit()
                    .frame(width: 26, height: 26)
                    .accessibilityHidden(true)
                Button { handleHomeButtonTapped() } label: {
                    Image(systemName: "house")
                        .frame(width: CullDesign.iconButtonSize, height: CullDesign.iconButtonSize)
                        .contentShape(Rectangle())
                }
                .iconButton()
                .help("Back to Home").accessibilityLabel("Back to Home")
                .hoverTooltip("Back to Home")
                Button(action: session.chooseInputFolder) {
                    Image(systemName: "folder")
                        .frame(width: CullDesign.iconButtonSize, height: CullDesign.iconButtonSize)
                        .contentShape(Rectangle())
                }
                .iconButton()
                .help("Choose another photo folder")
                .accessibilityLabel("Choose another photo folder")
                .hoverTooltip("Choose another photo folder")
                Button { openSettings() } label: {
                    Image(systemName: "gearshape")
                        .frame(width: CullDesign.iconButtonSize, height: CullDesign.iconButtonSize)
                        .contentShape(Rectangle())
                }
                .iconButton()
                .help("Settings").accessibilityLabel("Settings")
                .hoverTooltip("Settings")
                languageMenu
                // Full path breadcrumb (was just the last folder component before),
                // e.g. "Volumes / NIKON D5200 / DCIM / 101NIKON".
                Text(folderBreadcrumb)
                    .font(.subheadline.weight(.medium)).lineLimit(1).truncationMode(.head)
                    .help(session.inputFolder?.path ?? "")
                    .hoverTooltip(LocalizedStringKey(session.inputFolder?.path ?? ""))
                Spacer(minLength: 12)
                Text(String(format: L("progress_percent"), Int((session.progressFraction * 100).rounded())))
                    .font(.caption.monospacedDigit()).foregroundStyle(CullDesign.muted)
                    .contentTransition(.numericText())
                Text(session.progressText)
                    .font(.system(.subheadline, design: .monospaced)).foregroundStyle(.primary.opacity(0.86))
                    .contentTransition(.numericText())
            }
            .animation(reduceMotion ? nil : .easeOut(duration: 0.2), value: session.progressFraction)
            // Keep/Reject/Left counters: moved up here from the bottom bar and made
            // larger so progress is readable at a glance while culling.
            HStack(spacing: 18) {
                Text(String(format: L("count_keep_label"), session.keepCount)).foregroundStyle(CullDesign.green)
                    .contentTransition(.numericText())
                Text(String(format: L("count_reject_label"), session.rejectCount)).foregroundStyle(CullDesign.red)
                    .contentTransition(.numericText())
                Text(String(format: L("count_remaining_label"), session.remainingCount)).foregroundStyle(CullDesign.muted)
                    .contentTransition(.numericText())
                Spacer()
            }
            .font(.subheadline.weight(.bold)).monospacedDigit()
            .animation(reduceMotion ? nil : .spring(response: 0.3, dampingFraction: 0.7), value: session.keepCount)
            .animation(reduceMotion ? nil : .spring(response: 0.3, dampingFraction: 0.7), value: session.rejectCount)
            ProgressView(value: session.progressFraction)
                .tint(accent.bright)
                .controlSize(.small)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.25), value: session.progressFraction)
        }
        // The title bar is hidden, so keep clear of the traffic-light buttons (except in full screen).
        .padding(.leading, isFullScreen ? 22 : CullDesign.windowControlsInset)
        .padding(.trailing, 22)
        .padding(.top, 15).padding(.bottom, 11)
    }

    /// Builds a readable "Volumes / NIKON D5200 / DCIM / 101NIKON" style breadcrumb
    /// from the chosen folder's full path, instead of showing just its last component.
    private var folderBreadcrumb: String {
        guard let path = session.inputFolder?.path else { return "" }
        let parts = path.split(separator: "/").map(String.init)
        return parts.isEmpty ? path : parts.joined(separator: " / ")
    }

    private var viewerContent: some View {
        HStack(alignment: .center, spacing: 14) {
            // Preview now spans from the left edge; both side panels live together
            // on the right (was histogram-left / preview-center / info-right).
            PhotoViewer(state: session.previewState, assetID: session.currentAsset?.id, zoomCommand: zoomCommand)
                .id(session.currentAsset?.id)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            if showInfo, let asset = session.currentAsset {
                VStack(spacing: 14) {
                    InfoPanel(asset: asset, preview: session.previewState.loaded)
                    HistogramPanel(histogram: session.previewState.loaded?.histogram)
                    Spacer(minLength: 0)
                }
                .frame(width: CullDesign.sidePanelWidth)
                .frame(maxHeight: .infinity)
                .transition(panelTransition(from: .trailing))
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 8)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .animation(reduceMotion ? nil : .easeOut(duration: 0.15), value: session.navigationToken)
        .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: showInfo)
    }

    private func panelTransition(from edge: Edge) -> AnyTransition {
        reduceMotion ? .opacity : .move(edge: edge).combined(with: .opacity)
    }

    /// Keyboard-shortcut legend, anchored to the bottom-right corner (previously a
    /// plain, easy-to-miss row centered under the button bar).
    private var shortcutHintsBar: some View {
        HStack(spacing: 11) {
            ShortcutHint(key: "1", title: "Keep")
            ShortcutHint(key: "2", title: "Reject")
            ShortcutHint(key: "Z", title: "Undo")
            ShortcutHint(key: "Space", title: "Zoom")
            ShortcutHint(key: "I", title: "Info")
            ShortcutHint(key: "F", title: "Fullscreen")
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .glassBar()
    }

    private func feedbackBadge(_ feedback: CullingFeedback) -> some View {
        let color: Color = switch feedback { case .keep: CullDesign.green; case .reject: CullDesign.red; case .undo: accent.bright }
        let icon: String = switch feedback { case .keep: "checkmark"; case .reject: "xmark"; case .undo: "arrow.uturn.backward" }
        return HStack(spacing: 8) {
            Image(systemName: icon).font(.caption.weight(.bold))
            Text(feedback.titleKey).font(.caption.weight(.bold)).textCase(.uppercase)
        }
        .foregroundStyle(color)
        .padding(.horizontal, 13).padding(.vertical, 8)
        .background(.black.opacity(0.68), in: Capsule())
        .overlay(Capsule().stroke(color.opacity(0.38), lineWidth: 1))
        .accessibilityLabel(Text(feedback.titleKey))
    }

    private var applyingOverlay: some View {
        ZStack {
            Color.black.opacity(0.48).ignoresSafeArea()
            VStack(spacing: 13) {
                ProgressView().controlSize(.large)
                Text("Organizing photos…").font(.headline)
                Text(String(format: L("count_progress_fraction"), session.applyCompleted, session.applyTotal))
                    .font(.caption.monospacedDigit()).foregroundStyle(CullDesign.muted)
                ProgressView(value: Double(session.applyCompleted), total: Double(max(session.applyTotal, 1)))
                    .frame(width: 190)
            }
            .padding(24)
            .glassBar()
        }
        .transition(.opacity)
    }

    private var completedView: some View {
        VStack(spacing: 13) {
            Image(systemName: "checkmark.circle").font(.system(size: 44, weight: .ultraLight)).foregroundStyle(CullDesign.green)
            Text("Culling complete").font(.title2.weight(.medium))
            Text(String(format: L("count_completed_summary"), session.keepCount, session.rejectCount))
                .foregroundStyle(CullDesign.muted)
            Button("Review & Apply") { showReview = true }.primaryAction().controlSize(.large)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var controls: some View {
        VStack(spacing: 10) {
            HStack(spacing: 12) {
                Button(action: session.undo) { Image(systemName: "arrow.uturn.backward") }
                    .iconButton()
                    .help("Undo (Z)").accessibilityLabel("Undo last decision")
                    .hoverTooltip("Undo (Z)")
                    .disabled(!session.hasDecisions)
                Button { zoomCommand += 1 } label: { Image(systemName: "plus.magnifyingglass") }
                    .iconButton()
                    .help("Toggle 100% zoom (Space)").accessibilityLabel("Toggle 100 percent zoom")
                    .hoverTooltip("Zoom (Space)")
                    .disabled(session.isAtEnd)
                Button { withAnimation(reduceMotion ? nil : .easeOut(duration: 0.18)) { showInfo.toggle() } } label: {
                    Image(systemName: showInfo ? "info.circle.fill" : "info.circle")
                }
                .iconButton()
                .help("Info & histogram panels (I)").accessibilityLabel("Toggle info and histogram panels")
                .hoverTooltip("Info panels (I)")
                .disabled(session.isAtEnd)
                Spacer(minLength: 16)
                Button("Reject") { session.decide(.reject) }
                    .keyboardShortcut("2", modifiers: [])
                    .primaryAction(tint: CullDesign.red)
                    .hoverTooltip("Reject this photo (2)")
                    .disabled(session.isAtEnd)
                // Darker green fill: white text on the light green was only ~1.6:1.
                Button("Keep") { session.decide(.keep) }
                    .keyboardShortcut("1", modifiers: [])
                    .primaryAction(tint: CullDesign.keepFill)
                    .hoverTooltip("Keep this photo (1)")
                    .disabled(session.isAtEnd)
                Spacer(minLength: 16)
                Button { showReview = true } label: { Image(systemName: "tray.and.arrow.down") }
                    .iconButton()
                    .help("Review and apply changes").accessibilityLabel("Review and apply changes")
                    .hoverTooltip("Review & apply")
                    .disabled(!session.hasDecisions)
            }
            // Bigger controls throughout (Keep/Reject especially) so every button
            // in this row is comfortably clickable.
            .controlSize(.large)
        }
        .padding(.horizontal, 22)
        .padding(.top, 15).padding(.bottom, 16)
    }

    private func handleHomeButtonTapped() {
        if session.hasUnsavedCullingProgress {
            showHomeConfirm = true
        } else {
            withAnimation(reduceMotion ? nil : .spring(response: 0.4, dampingFraction: 0.82)) {
                session.resetToHome()
            }
        }
    }

    private func recordMouseActivity() {
        inactivityTask?.cancel()
        if !controlsVisible { withAnimation(reduceMotion ? nil : .easeOut(duration: 0.12)) { controlsVisible = true } }
        inactivityTask = Task {
            try? await Task.sleep(for: .seconds(2.5))
            guard !Task.isCancelled else { return }
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) { controlsVisible = false }
        }
    }

    private func handleKeyDown(_ event: NSEvent) -> Bool {
        guard !session.isScanning, !session.isApplying, !showReview, !showTutorial, !showHomeConfirm,
              session.transferOutcome == nil, session.errorMessage == nil else { return false }
        switch event.keyCode {
        case 18: session.decide(.keep); return true // 1
        case 6: session.undo(); return true // z
        case 19: session.decide(.reject); return true // 2
        case 49: zoomCommand += 1; return true // space
        case 3: NSApp.keyWindow?.toggleFullScreen(nil); return true // F
        case 34: showInfo.toggle(); return true // I
        default: return false
        }
    }
}
