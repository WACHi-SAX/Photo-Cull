import AppKit
import SwiftUI

struct KeyEventMonitor: NSViewRepresentable {
    let onKeyDown: (NSEvent) -> Bool
    let onMouseActivity: () -> Void

    func makeNSView(context: Context) -> EventView {
        let view = EventView()
        view.onKeyDown = onKeyDown
        view.onMouseActivity = onMouseActivity
        return view
    }

    func updateNSView(_ nsView: EventView, context: Context) {
        nsView.onKeyDown = onKeyDown
        nsView.onMouseActivity = onMouseActivity
    }

    final class EventView: NSView {
        var onKeyDown: ((NSEvent) -> Bool)?
        var onMouseActivity: (() -> Void)?
        private var monitor: Any?

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            guard monitor == nil else { return }
            monitor = NSEvent.addLocalMonitorForEvents(matching: [.keyDown, .mouseMoved]) { [weak self] event in
                if event.type == .mouseMoved {
                    self?.onMouseActivity?()
                    return event
                }
                return self?.onKeyDown?(event) == true ? nil : event
            }
        }

    }
}
