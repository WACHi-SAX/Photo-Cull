import AppKit
import SwiftUI

struct CompletionSheet: View {
    let outcome: TransferOutcome
    let onDismiss: () -> Void
    let onStartOver: () -> Void
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appAccent) private var accent

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: outcome.failures.isEmpty ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .font(.system(size: 48, weight: .light))
                .foregroundStyle(outcome.failures.isEmpty ? CullDesign.green : .orange)
            VStack(spacing: 6) {
                Group {
                    if outcome.failures.isEmpty { Text("Done") } else { Text("Organized with notes") }
                }
                .font(.title2.weight(.semibold))
                Text(String(format: L("count_photos_transferred"), outcome.transferred, outcome.mode.completedVerb))
                    .foregroundStyle(CullDesign.muted)
                if !outcome.failures.isEmpty {
                    Text(String(format: L("count_files_failed"), outcome.failures.count))
                        .font(.caption).multilineTextAlignment(.center).foregroundStyle(.orange)
                }
            }
            HStack(spacing: 10) {
                Button("View Selected") { reveal("Selected") }
                Button("View Rejected") { reveal("Rejected") }
            }
            Divider().opacity(0.25).padding(.horizontal, 24)
            VStack(spacing: 10) {
                // Primary action: go back to the welcome screen so the user
                // can cull another folder without restarting the app.
                Button("Start Over") {
                    dismiss()
                    onStartOver()
                }
                .primaryAction()
                .keyboardShortcut(.defaultAction)
                .accessibilityHint("Returns to the home screen to choose a new folder")
                // Secondary: just close the sheet and stay on the completion screen.
                Button("Done") {
                    dismiss()
                    onDismiss()
                }
                .foregroundStyle(CullDesign.muted)
                .buttonStyle(.plain)
            }
        }
        .padding(28)
        .frame(width: 390)
        .background(SeaBackdrop())
        .preferredColorScheme(.dark)
        .tint(accent.bright)
    }

    private func reveal(_ folder: String) {
        NSWorkspace.shared.activateFileViewerSelecting([outcome.destination.appendingPathComponent(folder)])
    }
}
