import SwiftUI

/// Histogram card shown beside the preview (right side, under the info panel).
struct HistogramPanel: View {
    let histogram: Histogram?
    @Environment(\.appAccent) private var accent

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("HISTOGRAM")
                .font(.caption2.weight(.semibold)).tracking(0.6)
                .foregroundStyle(accent.bright)
            HistogramGraph(histogram: histogram)
                .frame(height: 110)
                .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                .accessibilityLabel("Histogram")
                .accessibilityValue(histogram == nil ? "Not available" : "Red, green, blue and luminance distribution")
            HStack {
                Text("Shadows")
                Spacer()
                Text("Highlights")
            }
            .font(.caption2)
            .foregroundStyle(CullDesign.muted)
        }
        .padding(12)
        .glassBar()
    }
}

private struct HistogramGraph: View {
    let histogram: Histogram?

    var body: some View {
        Canvas { context, size in
            context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(.black.opacity(0.35)))

            // Quarter-tone guides.
            var grid = Path()
            for step in 1..<4 {
                let x = size.width * CGFloat(step) / 4
                grid.move(to: CGPoint(x: x, y: 0))
                grid.addLine(to: CGPoint(x: x, y: size.height))
            }
            context.stroke(grid, with: .color(CullDesign.hairline), lineWidth: 0.5)

            guard let histogram else { return }
            let peak = Double(max(histogram.peak, 1))

            func area(_ bins: [Int]) -> Path {
                var path = Path()
                path.move(to: CGPoint(x: 0, y: size.height))
                for (index, value) in bins.enumerated() {
                    let x = size.width * CGFloat(index) / CGFloat(bins.count - 1)
                    let level = min(Double(value) / peak, 1)
                    path.addLine(to: CGPoint(x: x, y: size.height * (1 - CGFloat(level))))
                }
                path.addLine(to: CGPoint(x: size.width, y: size.height))
                path.closeSubpath()
                return path
            }

            context.fill(area(histogram.luma), with: .color(.white.opacity(0.16)))
            context.drawLayer { layer in
                layer.blendMode = .plusLighter
                layer.fill(area(histogram.red), with: .color(Color(red: 1.0, green: 0.22, blue: 0.22).opacity(0.72)))
                layer.fill(area(histogram.green), with: .color(Color(red: 0.22, green: 1.0, blue: 0.35).opacity(0.72)))
                layer.fill(area(histogram.blue), with: .color(Color(red: 0.25, green: 0.50, blue: 1.0).opacity(0.72)))
            }
        }
    }
}
