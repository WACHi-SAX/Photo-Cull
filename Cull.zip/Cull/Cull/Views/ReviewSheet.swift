import SwiftUI

struct ReviewSheet: View {
    @ObservedObject var session: CullingSession
    let onApply: () -> Void
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appAccent) private var accent
    @State private var showConfirmation = false

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            VStack(alignment: .leading, spacing: 5) {
                Text("Ready to organize").font(.title2.weight(.semibold))
                Text("Nothing changes until you confirm below.")
                    .font(.callout).foregroundStyle(CullDesign.muted)
            }
            HStack(spacing: 12) {
                decisionSummary("Keep", count: session.keepCount, color: CullDesign.green)
                decisionSummary("Reject", count: session.rejectCount, color: CullDesign.red)
            }
            VStack(alignment: .leading, spacing: 7) {
                Text("Destination folder").font(.headline)
                HStack {
                    Group {
                        if let path = session.destinationFolder?.path {
                            Text(path)
                        } else {
                            Text("Choose where to create Selected and Rejected")
                        }
                    }
                        .lineLimit(1)
                        .truncationMode(.middle)
                        .foregroundStyle(session.destinationFolder == nil ? .secondary : .primary)
                        .help(session.destinationFolder?.path ?? "")
                    Spacer(minLength: 8)
                    Button("Choose…", action: session.chooseDestinationFolder)
                }
                .padding(10)
                .background(CullDesign.panel, in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous).stroke(CullDesign.hairline, lineWidth: 1))
            }
            VStack(alignment: .leading, spacing: 7) {
                Text("File handling").font(.headline)
                Picker("File handling", selection: $session.transferMode) {
                    ForEach(TransferMode.allCases) { Text($0.localizedName).tag($0) }
                }
                .pickerStyle(.radioGroup)
                .labelsHidden()
            }
            Text("Kept files go to Selected; rejected files go to Rejected. Name conflicts receive a numbered suffix, and no file is permanently deleted.")
                .font(.callout)
                .foregroundStyle(.secondary)
            HStack {
                Button("Cancel") { dismiss() }
                    .keyboardShortcut(.cancelAction)
                Spacer()
                Button("Apply Changes") { showConfirmation = true }
                    .primaryAction()
                    .disabled(!session.hasDecisions || session.destinationFolder == nil)
            }
        }
        .padding(24)
        .frame(width: 510)
        .background(SeaBackdrop())
        .preferredColorScheme(.dark)
        .tint(accent.bright)
        .alert("Apply file changes?", isPresented: $showConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Apply Changes") {
                dismiss()
                onApply()
            }
        } message: {
            Text(String(
                format: L("count_transfer_summary"),
                session.keepCount, session.rejectCount, session.transferMode.localizedName
            ))
        }
    }

    private func decisionSummary(_ label: LocalizedStringKey, count: Int, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("\(count)").font(.system(size: 34, weight: .bold, design: .rounded))
            Text(label).font(.caption.weight(.bold)).textCase(.uppercase).foregroundStyle(color)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(color.opacity(0.13), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(color.opacity(0.28), lineWidth: 1))
        .accessibilityElement(children: .combine)
    }
}
