import AppKit
import SwiftUI

/// Intercepts the window's own close button (the red traffic light), which never
/// goes through the app delegate's `applicationShouldTerminate` — that only fires
/// for Cmd+Q / the Quit menu. SwiftUI's WindowGroup exposes no other hook for
/// this, so this drops down to a plain NSView that takes over the window's
/// delegate just to veto/allow the close.
struct WindowCloseGuard: NSViewRepresentable {
    let shouldClose: () -> Bool

    func makeNSView(context: Context) -> GuardView {
        let view = GuardView()
        view.shouldClose = shouldClose
        return view
    }

    func updateNSView(_ nsView: GuardView, context: Context) {
        nsView.shouldClose = shouldClose
    }

    @MainActor
    final class GuardView: NSView, NSWindowDelegate {
        var shouldClose: (() -> Bool)?
        private weak var attachedWindow: NSWindow?

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            guard let window, attachedWindow !== window else { return }
            attachedWindow = window
            window.delegate = self
        }

        func windowShouldClose(_ sender: NSWindow) -> Bool {
            shouldClose?() ?? true
        }
    }
}
