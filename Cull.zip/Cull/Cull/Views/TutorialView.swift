import SwiftUI

private struct TutorialStep {
    let title: LocalizedStringKey
    let body: LocalizedStringKey
}

@MainActor
private let tutorialSteps: [TutorialStep] = [
    TutorialStep(title: "Welcome to Photo Cull",
                 body: "Fast, keyboard-first photo culling. This quick tour shows you around."),
    TutorialStep(title: "Choose a folder",
                 body: "Pick a folder of photos and Photo Cull scans it for JPEG, PNG, HEIC and RAW files."),
    TutorialStep(title: "Keep or Reject",
                 body: "Press 1 to Keep or 2 to Reject the photo on screen. Made a mistake? Press Z to undo."),
    TutorialStep(title: "Check focus up close",
                 body: "Press Space or double-click to zoom in. Drag to pan around, or pinch on a trackpad to zoom further."),
    TutorialStep(title: "Review, then apply",
                 body: "When you're done, review your choices — Photo Cull copies or moves files into Selected and Rejected folders for you.")
]

/// First-launch onboarding: full-window, with each step shown as a small live
/// mockup built from the app's own components (ShortcutHint, PrimaryButtonStyle,
/// CullDesign colors) rather than a generic icon, so it reads as a preview of the
/// real UI rather than a separate slideshow. Tracked by @AppStorage("hasSeenTutorial")
/// and replayable from Settings → About.
struct TutorialView: View {
    let onFinish: () -> Void
    @State private var step = 0
    @Environment(\.appAccent) private var accent
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 20)
            ZStack {
                sceneView(for: step)
                    .id(step)
                    .transition(reduceMotion ? .opacity :
                        .asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal: .move(edge: .leading).combined(with: .opacity)
                        ))
            }
            .frame(maxWidth: 720, maxHeight: .infinity)
            .clipped()
            Spacer(minLength: 20)
            footer
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background { SeaBackdrop().ignoresSafeArea() }
        .animation(reduceMotion ? nil : .spring(response: 0.4, dampingFraction: 0.8), value: step)
        .transition(.opacity)
    }

    private var footer: some View {
        VStack(spacing: 18) {
            VStack(spacing: 7) {
                Text(tutorialSteps[step].title).font(.title2.weight(.semibold))
                Text(tutorialSteps[step].body)
                    .font(.callout).foregroundStyle(CullDesign.muted)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: 460)
            }
            HStack(spacing: 7) {
                ForEach(tutorialSteps.indices, id: \.self) { index in
                    Capsule()
                        .fill(index == step ? accent.bright : CullDesign.muted.opacity(0.3))
                        .frame(width: index == step ? 20 : 7, height: 7)
                }
            }
            HStack(spacing: 18) {
                Button("Skip Tutorial") { finish() }
                    .buttonStyle(.plain)
                    .foregroundStyle(CullDesign.muted)
                    .accessibilityHint("Closes the tutorial")
                Button(step == tutorialSteps.count - 1 ? "Get Started" : "Next") { advance() }
                    .primaryAction()
                    .controlSize(.large)
                    .keyboardShortcut(.defaultAction)
            }
        }
        .padding(.bottom, 46)
    }

    @ViewBuilder
    private func sceneView(for step: Int) -> some View {
        switch step {
        case 0: welcomeScene
        case 1: chooseFolderScene
        case 2: keepRejectScene
        case 3: zoomScene
        default: reviewScene
        }
    }

    // MARK: Scene 1 — Welcome
    private var welcomeScene: some View {
        VStack(spacing: 16) {
            Image("AppLogo")
                .resizable().interpolation(.high).scaledToFit()
                .frame(width: 108, height: 108)
                .shadow(color: accent.bright.opacity(0.4), radius: 22)
            Text("Photo Cull").font(.system(size: 30, weight: .semibold, design: .rounded))
        }
    }

    // MARK: Scene 2 — Choose a folder (mirrors the real welcome screen's button + a drop hint)
    private var chooseFolderScene: some View {
        VStack(spacing: 18) {
            Image(systemName: "folder.fill")
                .font(.system(size: 52, weight: .light))
                .foregroundStyle(accent.bright)
            Button("Choose Photo Folder") {}
                .primaryAction()
                .controlSize(.large)
                .allowsHitTesting(false)
            Text("or drag a folder in").font(.caption).foregroundStyle(CullDesign.muted)
        }
    }

    // MARK: Scene 3 — Keep or Reject (the actual bottom control bar, non-interactive)
    private var keepRejectScene: some View {
        VStack(spacing: 22) {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color.black.opacity(0.5))
                .frame(width: 240, height: 160)
                .overlay(Image(systemName: "photo").font(.system(size: 30)).foregroundStyle(CullDesign.muted))
            HStack(spacing: 14) {
                Button("Reject") {}.primaryAction(tint: CullDesign.red).controlSize(.large).allowsHitTesting(false)
                Button("Keep") {}.primaryAction(tint: CullDesign.keepFill).controlSize(.large).allowsHitTesting(false)
            }
            HStack(spacing: 11) {
                ShortcutHint(key: "1", title: "Keep")
                ShortcutHint(key: "2", title: "Reject")
                ShortcutHint(key: "Z", title: "Undo")
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            .glassBar()
        }
    }

    // MARK: Scene 4 — Zoom & pan
    private var zoomScene: some View {
        VStack(spacing: 18) {
            ZStack(alignment: .bottomTrailing) {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.black.opacity(0.5))
                    .frame(width: 260, height: 180)
                    .overlay(Image(systemName: "mountain.2.fill").font(.system(size: 36)).foregroundStyle(CullDesign.muted))
                Text("250%")
                    .font(.caption2.weight(.semibold).monospacedDigit())
                    .foregroundStyle(.white.opacity(0.9))
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(.black.opacity(0.55), in: Capsule())
                    .padding(10)
            }
            HStack(spacing: 11) {
                ShortcutHint(key: "Space", title: "Zoom")
                ShortcutHint(key: "F", title: "Fullscreen")
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            .glassBar()
        }
    }

    // MARK: Scene 5 — Review & apply
    private var reviewScene: some View {
        VStack(spacing: 16) {
            Image(systemName: "checkmark.circle")
                .font(.system(size: 44, weight: .ultraLight)).foregroundStyle(CullDesign.green)
            HStack(spacing: 22) {
                VStack(spacing: 6) {
                    Image(systemName: "folder.fill").font(.title2).foregroundStyle(CullDesign.green)
                    Text("Selected").font(.caption).foregroundStyle(CullDesign.muted)
                }
                VStack(spacing: 6) {
                    Image(systemName: "folder.fill").font(.title2).foregroundStyle(CullDesign.red)
                    Text("Rejected").font(.caption).foregroundStyle(CullDesign.muted)
                }
            }
            Button("Review & Apply") {}.primaryAction().controlSize(.large).allowsHitTesting(false)
        }
    }

    private func advance() {
        if step == tutorialSteps.count - 1 { finish() } else { step += 1 }
    }

    private func finish() {
        withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) { onFinish() }
    }
}

extension Notification.Name {
    /// Posted by Settings → About's "Show Tutorial Again" so the main window
    /// (a separate SwiftUI scene) can bring the tutorial back up.
    static let replayTutorial = Notification.Name("com.wachi.Cull.replayTutorial")
}
