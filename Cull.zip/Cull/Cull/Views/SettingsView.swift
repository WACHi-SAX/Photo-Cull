import SwiftUI

struct SettingsView: View {
    var body: some View {
        TabView {
            LanguageSettingsTab()
                .tabItem { Label("Language", systemImage: "globe") }
            PersonalizeSettingsTab()
                .tabItem { Label("Personalize", systemImage: "paintbrush") }
            AboutSettingsTab()
                .tabItem { Label("About", systemImage: "info.circle") }
        }
        .frame(width: 440, height: 340)
    }
}

private struct LanguageSettingsTab: View {
    @AppStorage(AppLanguage.storageKey) private var appLanguageRaw = AppLanguage.default.rawValue

    var body: some View {
        Form {
            Picker("Language", selection: $appLanguageRaw) {
                ForEach(AppLanguage.allCases) { language in
                    Text(language.nativeName).tag(language.rawValue)
                }
            }
            .pickerStyle(.inline)
            .labelsHidden()
        }
        .formStyle(.grouped)
    }
}

private struct PersonalizeSettingsTab: View {
    @AppStorage(AppTheme.storageKey) private var themeRaw = AppTheme.default.rawValue
    @AppStorage(AccentOption.storageKey) private var accentRaw = AccentOption.default.rawValue

    var body: some View {
        Form {
            Section("Theme") {
                Picker("Theme", selection: $themeRaw) {
                    ForEach(AppTheme.allCases) { theme in
                        Label(theme.titleKey, systemImage: theme.icon).tag(theme.rawValue)
                    }
                }
                .pickerStyle(.inline)
                .labelsHidden()
            }
            Section("Accent Color") {
                HStack(spacing: 16) {
                    ForEach(AccentOption.allCases) { option in
                        Button {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { accentRaw = option.rawValue }
                        } label: {
                            Circle()
                                .fill(option.fill)
                                .frame(width: 30, height: 30)
                                .overlay(
                                    Circle().stroke(.primary, lineWidth: accentRaw == option.rawValue ? 2.5 : 0)
                                        .padding(-3)
                                )
                        }
                        .buttonStyle(.plain)
                        .help(option.titleKey)
                        .accessibilityLabel(option.titleKey)
                    }
                }
                .padding(.vertical, 4)
            }
        }
        .formStyle(.grouped)
    }
}

private struct AboutSettingsTab: View {
    var body: some View {
        VStack(spacing: 12) {
            Image("AppLogo")
                .resizable().interpolation(.high).scaledToFit()
                .frame(width: 72, height: 72)
                .shadow(color: .black.opacity(0.15), radius: 8)
            Text("Photo Cull").font(.title2.weight(.semibold))
            Text(String(format: L("about_version"), "1.0"))
                .foregroundStyle(.secondary)
            Text("Fast photo selection for photographers.")
                .font(.callout).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button("Show Tutorial Again") {
                NotificationCenter.default.post(name: .replayTutorial, object: nil)
            }
            .buttonStyle(.link)
            .padding(.top, 4)
        }
        .padding(32)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
