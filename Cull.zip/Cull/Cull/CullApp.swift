import AppKit
import SwiftUI

/// Shows a native confirmation when quitting mid-culling, since SwiftUI has no
/// view on screen by the time termination runs — an NSAlert is the standard,
/// synchronous way to block quitting until the person answers.
@MainActor
final class CullAppDelegate: NSObject, NSApplicationDelegate {
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard let session = CullingSession.shared else { return .terminateNow }
        return session.confirmDiscardOrSaveBeforeClosing() ? .terminateNow : .terminateCancel
    }
}

@main
struct CullApp: App {
    @NSApplicationDelegateAdaptor(CullAppDelegate.self) private var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
                .frame(minWidth: 1080, minHeight: 640)
        }
        .defaultSize(width: 1280, height: 820)
        .windowStyle(.hiddenTitleBar)

        Settings {
            SettingsView()
        }
    }
}
