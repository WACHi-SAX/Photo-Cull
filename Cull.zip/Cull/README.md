# Cull

Cull is a native SwiftUI macOS MVP for keyboard-first photo culling. Open `Cull.xcodeproj` in Xcode 16+ and run the `Cull` scheme.

It recognizes JPEG, PNG, HEIC/HEIF, and NEF, CR2, CR3, ARW, RAF, RW2, ORF, PEF, and DNG files. RAW files stay as the source asset: ImageIO is asked for an embedded thumbnail first, with macOS native decoding only as the fallback.

Keyboard: `1` keep, `2` reject, and `Z` undo. Review decisions before applying. Files are copied by default (or can be moved) to `Selected` and `Rejected` folders under the chosen destination. Existing names are never overwritten.

The window shows photo information (top-right) and a histogram (bottom-left) beside the preview; press `I` to hide or show both panels.

Use the globe icon (on the welcome screen and in the top bar) to switch the app's language. Cull ships in English (default), Thai, Spanish, French, German, Japanese, Korean, Simplified Chinese, Portuguese, and Russian.

A short first-launch tutorial explains the basics (replay it any time from Settings → About → "Show Tutorial Again"). The house icon in the top bar returns to the welcome screen; if you haven't finished culling, it (and quitting the app) offers to save your progress so you can pick the same folder back up later, exactly where you left off.

Settings (⌘,) has three tabs: Language, Personalize (light/dark/system theme and an accent color), and About (version number, tutorial replay).
